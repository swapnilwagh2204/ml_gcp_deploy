#1. dlp=data loss Prevention

# to secure the sensitive data like credit card,salaries.address

# it automatically detect the address and credit card numbers along with over 120 predefined info types. Each

# what type of data dlp scan?

# strams of data 
# structured text 
# cloud storage
# bigquery
# images




# 2.data deidentification: 
# its process of removing personal information from the data.(hiding)
# techniques-> mask,delete,tokenize,


# date shifting--:> shift data values by random amount of time.
# image redaction- hiding data from images.  masking with opaque rectangle
# problem with image redaction is that we cannot see what the data is about.
# so we can use the masking there. simply email addresses is masked b name <email id>


# bucketing : buckets created -- eg. director developer manager
#             salary hide hote.

# cryptographic key-> reidentify-deidentify the data.



# 3. tokenization with dlp.
#     crypto-based tokenization is also called as pseudonymization ,
#     use encrypted keys in place of sensitive values.

#     3 types:
#     1.deterministic encryption
#         detected data is replaced by with an encrypted value and prepended with the optional surrogate annotation.
#         supports most input type and also authentication.

#     2.format preserving encryption: 
#         same set of string  values idhar udhar.

#     3.cryptographic hashing 
#         here dlp replaces the sensitive data with hash value.
#         it uses one way token so it cant be reversed.
#         perfect solution is you want a unique valuwe....but its cant be reversed.

#     refrential integrity:
#         no loss of relation between the data. 
    
#     reidentification:
#         reacess the data using same key used for deidentification.

    
# dlp templates:
#     it allows you to save dlp configuration  details and reuse them against any data that you might have.

#     types of templates:

#     1.inspection templates:
#             info types:
#             likelihood
#             maximum finding
#             exclusions
#             custom infotype





def inspect_with_medical_record_number_custom_regex_detector(project, content_string,):
    """Uses the Data Loss Prevention API to analyze string with medical record
       number custom regex detector

    Args:
        project: The Google Cloud project id to use as a parent resource.
        content_string: The string to inspect.

    Returns:
        None; the response from the API is printed to the terminal.
    """
content ="Patients MRN 444-5-22222"

def inspect_with_medical_record_number_custom_regex_detector(project, content):

  
    import google.cloud.dlp

# 344-1-34567
   
    dlp = google.cloud.dlp_v2.DlpServiceClient()
    custom_info_types = [
        {
            "info_type": {"name": "C_MRN"},
            "regex": {"pattern": "[1-9]{3}-[1-9]{1}-[1-9]{5}"},
            "likelihood": google.cloud.dlp_v2.Likelihood.POSSIBLE,
        }
    ]
    inspect_config = {
        "custom_info_types": custom_info_types,
        "include_quote": True,
    }
    item = {"value": content}
    parent = f"projects/{project}"

    response = dlp.inspect_content(
        request={"parent": parent, "inspect_config": inspect_config, "item": item}
    )
    if response.result.findings:
        for finding in response.result.findings:
            print(f"Quote: {finding.quote}")
            print(f"Info type: {finding.info_type.name}")
            print(f"Likelihood: {finding.likelihood}")
    else:
        print("No findings.")
        
inspect_with_medical_record_number_custom_regex_detector('kafka-269515',content)
