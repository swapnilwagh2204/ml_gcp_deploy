content ="Patients MRN 444-5-22222,google,facebook.amazon,apple,tesla"

def inspect_with_medical_record_number_custom_regex_detector(project, content):

  
    import google.cloud.dlp

# 344-1-34567
   
    dlp = google.cloud.dlp_v2.DlpServiceClient()
    custom_info_types = [
       {
  "customInfoTypes":[
    {
      "infoType":{
        "name":"[]tesla]"
      },
      "likelihood":google.cloud.dlp_v2.Likelihood.POSSIBLE,

      "dictionary":content
    }
  ]
}
    ]
    inspect_config = {
        "custom_info_types": custom_info_types,
        "include_quote": True,
    }
    item = {"value": content}
    parent = f"projects/{project}"

    response = dlp.inspect_content(
        request={"parent": parent, "inspect_config": inspect_config, "item": item}
    )
    if response.result.findings:
        for finding in response.result.findings:
            print(f"Quote: {finding.quote}")
            print(f"Info type: {finding.info_type.name}")
            print(f"Likelihood: {finding.likelihood}")
    else:
        print("No findings.")
        
inspect_with_medical_record_number_custom_regex_detector('kafka-269515',content)
