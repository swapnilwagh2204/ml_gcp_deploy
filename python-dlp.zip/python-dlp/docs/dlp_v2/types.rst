Types for Google Cloud Dlp v2 API
=================================

.. automodule:: google.cloud.dlp_v2.types
    :members:
    :show-inheritance:
