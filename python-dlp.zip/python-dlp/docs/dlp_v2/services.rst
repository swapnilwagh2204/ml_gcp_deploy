Services for Google Cloud Dlp v2 API
====================================

.. automodule:: google.cloud.dlp_v2.services.dlp_service
    :members:
    :inherited-members:
